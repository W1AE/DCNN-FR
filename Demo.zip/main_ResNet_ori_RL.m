clear all;
gpuDevice(1)
loopNB = 8;%No. Epoch
rd_rate=[0 0 0.25 0.25 0.5 0.5 0.75 0.75];%

outputFolder = fullfile('Caltech256');                                           %%Caltech256
imds = imageDatastore(outputFolder,'IncludeSubfolders',true,'LabelSource','foldernames');
[trainDigitData,testDigitData] = splitEachLabel(imds,30,'randomized');%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
trainDigitData.ReadFcn = @(filename)readAndPreprocessImage(filename);
testDigitData.ReadFcn = @(filename)readAndPreprocessImage(filename);
numClasses = 257;

net = resnet50;
lgraph = layerGraph(net);
lgraph = removeLayers(lgraph, {'fc1000','fc1000_softmax','ClassificationLayer_fc1000'});
newLayers = [
    fullyConnectedLayer(numClasses,'Name','fc2')
    softmaxLayer('Name','softmax')
    classificationLayer('Name','classoutput')];
lgraph = addLayers(lgraph,newLayers);
lgraph = connectLayers(lgraph,'avg_pool','fc2');
connections = lgraph.Connections;
layers = lgraph.Layers;
NB_layer=Random_layers(rd_rate(1), layers);
layers(NB_layer) = freezeWeights(layers(NB_layer));
lgraph = createLgraphUsingConnections(layers,connections);
Size=32;
rate2=[10e-4 10e-4 10e-4 10e-5 10e-5 10e-5 10e-6 10e-6 10e-6 10e-6 10e-6 10e-6 10e-6 10e-6];


for i = 1:loopNB
    %Train the network  fine-tune
    options = trainingOptions('sgdm',...
        'LearnRateSchedule','piecewise',...
        'LearnRateDropFactor',0.1,...
        'LearnRateDropPeriod',100,...
        'MaxEpochs',1,...
        'InitialLearnRate',rate2(i),...
        'MiniBatchSize',Size);
    convnet = trainNetwork(trainDigitData,lgraph,options);
    YPred = classify(convnet,testDigitData,'MiniBatchSize',Size);
    YTest = testDigitData.Labels;
    test_accuracy_bef(i) = sum(YPred==YTest)/numel(YTest)

    lgraph = layerGraph(convnet);
    layers = lgraph.Layers;
    connections = lgraph.Connections;
    NB_layer=Random_layers(rd_rate(i+1), layers);
    layers(NB_layer) = freezeWeights(layers(NB_layer));
    lgraph = createLgraphUsingConnections(layers,connections);
end