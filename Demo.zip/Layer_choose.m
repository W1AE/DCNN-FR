

        name='avg_pool';


trainingFeatures = activations(convnet, trainDigitData, name,'MiniBatchSize',Size);
a1=size(trainingFeatures,1);%Only for Matlab2018
a2=size(trainingFeatures,2);
a3=size(trainingFeatures,3);
a4=size(trainingFeatures,4);
X_train1=reshape(trainingFeatures,[a1*a2*a3,a4])';


        InputWeight{1}=convnet.Layers(175).Weights;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_a=[trainDigitData.Labels;testDigitData.Labels];
D_tr=size(trainDigitData.Labels,1);
D_te=size(testDigitData.Labels,1);
LaBel=double(T_a);
T_train1=LaBel(1:D_tr);
T_test1=LaBel(D_tr+1:end);

train_label=grp2idx(trainDigitData.Labels);
T_train=train_label;
test_label=grp2idx(testDigitData.Labels);
T_test=test_label;
save Training X_train1 -v7.3;
save T_train T_train -v7.3;
save T_test T_test -v7.3;