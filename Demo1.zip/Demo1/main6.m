%% ResNet-50 trained w/ the proposed method (Adam + MP); rate2=[10e-4 10e-4 10e-4 10e-5 10e-5 10e-5 10e-6 10e-6 10e-6];

clear all;
%% [1] Pre-processing
gpuDevice(6)
loopNB = 8;%No. Epoch
batch_num=1;% No. batches
L_Rate=0.5;% MP-based Learning Rate
r_a=[1 1 0.75 0.75 0.5 0.5 0.25 0.25];% Random Activation Rate

rd_rate=1-r_a;
outputFolder = fullfile('/data/cvssl_19_01/Place/dataset/Caltech256');%The path of Caltech256 dataset
imds = imageDatastore(outputFolder,'IncludeSubfolders',true,'LabelSource','foldernames');
[trainDigitData,testDigitData] = splitEachLabel(imds,30,'randomized');
trainDigitData.ReadFcn = @(filename)readAndPreprocessImage(filename);
testDigitData.ReadFcn = @(filename)readAndPreprocessImage(filename);
transferDigitData = splitEachLabel(imds,1,'randomized');
transferDigitData.ReadFcn = @(filename)readAndPreprocessImage(filename);
numClasses = 257;

net = resnet50;
lgraph = layerGraph(net);
lgraph = removeLayers(lgraph, {'fc1000','fc1000_softmax','ClassificationLayer_fc1000'});
newLayers = [
    fullyConnectedLayer(numClasses,'Name','fc2')
    softmaxLayer('Name','softmax')
    classificationLayer('Name','classoutput')];
lgraph = addLayers(lgraph,newLayers);
lgraph = connectLayers(lgraph,'avg_pool','fc2');
connections = lgraph.Connections;
layers = lgraph.Layers;
NB_layer=Random_layers(rd_rate(1), layers);
layers(NB_layer) = freezeWeights(layers(NB_layer));
lgraph = createLgraphUsingConnections(layers,connections);
Size=32;
rate2=[10e-4 10e-4 10e-4 10e-5 10e-5 10e-5 10e-6 10e-6 10e-6];% BP-based Learning Rate

%% [2] Training the DCNN
for i = 1:loopNB
    %Train the network
    options = trainingOptions('adam',...
        'LearnRateSchedule','piecewise',...
        'LearnRateDropFactor',0.1,...
        'LearnRateDropPeriod',100,...
        'MaxEpochs',1,...
        'InitialLearnRate',rate2(i),...
        'MiniBatchSize',Size);
    convnet = trainNetwork(trainDigitData,lgraph,options);
    

    %% The proposed Adam + MP
    Layer_choose;
    preprocessing_rl(batch_num,numClasses);
    
    [InputWeight4]=T33_new_cnn(InputWeight,batch_num,0,0.5,1,L_Rate,1);
    lgraph = layerGraph(convnet);
    layers = lgraph.Layers;
    connections = lgraph.Connections;
    layers(175).Weights=InputWeight4{1};
    lgraph = createLgraphUsingConnections(layers,connections);
    options = trainingOptions('sgdm','MaxEpochs',1,...
        'InitialLearnRate',10e-50,'MiniBatchSize',Size);
    convnet = trainNetwork(transferDigitData,lgraph,options);
    YPred = classify(convnet,testDigitData,'MiniBatchSize',Size);
    YTest = testDigitData.Labels;
    test_accuracy(i) = sum(YPred==YTest)/numel(YTest)
    if i<loopNB
        lgraph = layerGraph(convnet);
        layers = lgraph.Layers;
        connections = lgraph.Connections;
        NB_layer=Random_layers(rd_rate(i+1), layers);
        layers(NB_layer) = freezeWeights(layers(NB_layer));
        lgraph = createLgraphUsingConnections(layers,connections);
    end
end