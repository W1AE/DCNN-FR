%% ResNet-50 trained w/ the Adam method; rate2=[10e-4 10e-4 10e-4 10e-5 10e-5 10e-5 10e-6 10e-6 10e-6];

clear all;
%% [1] Pre-processing
gpuDevice(5)
loopNB = 8;%No. Epoch

outputFolder = fullfile('/data/cvssl_19_01/Place/dataset/Caltech256');%The path of Caltech256 dataset
imds = imageDatastore(outputFolder,'IncludeSubfolders',true,'LabelSource','foldernames');
[trainDigitData,testDigitData] = splitEachLabel(imds,30,'randomized');%Randomly select 30 images per category to form the training set, while the rest for testing.
trainDigitData.ReadFcn = @(filename)readAndPreprocessImage(filename);
testDigitData.ReadFcn = @(filename)readAndPreprocessImage(filename);
numClasses = 257;% No. Category

net = resnet50;
lgraph = layerGraph(net);
lgraph = removeLayers(lgraph, {'fc1000','fc1000_softmax','ClassificationLayer_fc1000'});
newLayers = [
    fullyConnectedLayer(numClasses,'Name','fc2')
    softmaxLayer('Name','softmax')
    classificationLayer('Name','classoutput')];
lgraph = addLayers(lgraph,newLayers);
lgraph = connectLayers(lgraph,'avg_pool','fc2');
Size=32;
rate2=[10e-4 10e-4 10e-4 10e-5 10e-5 10e-5 10e-6 10e-6 10e-6];% BP-based Learning Rate

%% [2] Train the DCNN
for i = 1:loopNB
    %Train the ResNet-50 
    options = trainingOptions('adam',...
        'LearnRateSchedule','piecewise',...
        'LearnRateDropFactor',0.1,...
        'LearnRateDropPeriod',100,...
        'MaxEpochs',1,...
        'InitialLearnRate',rate2(i),...
        'MiniBatchSize',Size);
    convnet = trainNetwork(trainDigitData,lgraph,options);
    YPred = classify(convnet,testDigitData,'MiniBatchSize',Size);
    YTest = testDigitData.Labels;
    test_accuracy_bef(i) = sum(YPred==YTest)/numel(YTest)

    lgraph = layerGraph(convnet);
    layers = lgraph.Layers;
    connections = lgraph.Connections;
    lgraph = createLgraphUsingConnections(layers,connections);
end