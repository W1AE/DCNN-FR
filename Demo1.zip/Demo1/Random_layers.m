function [value]=Random_layers(rate, layers)
layer_NO=[];
n=size(layers,1);
for i=1:n
    props = properties(layers(i));
    for p = 1:numel(props)
        propName = props{p};
        if ~isempty(regexp(propName, 'FilterSize', 'once'))
            layer_NO=[layer_NO i];
        end
    end
end
rand('state',sum(100*clock));
rn=round(size(layer_NO,2)*rate);
idx_rand = randperm(size(layer_NO,2));
v=layer_NO(idx_rand(1,1:rn));
value=sort(v);
end